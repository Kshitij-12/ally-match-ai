-- Create counselors table with therapeutic style profiles
CREATE TABLE public.counselors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  bio TEXT,
  specializations TEXT[],
  languages TEXT[],
  gender TEXT,
  years_experience INTEGER,
  hourly_rate DECIMAL(10,2),
  therapeutic_styles JSONB, -- AI-derived style scores
  persona_scores JSONB, -- empathy, directness, CBT-focus, etc.
  availability_schedule JSONB,
  profile_image_url TEXT,
  verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create intake submissions table
CREATE TABLE public.intake_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  free_text_input TEXT NOT NULL, -- "What brings you here today?"
  structured_data JSONB, -- filters, preferences
  ai_persona_score JSONB, -- AI-derived persona preferences
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create counselor matches table
CREATE TABLE public.counselor_matches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  intake_submission_id UUID REFERENCES public.intake_submissions(id) ON DELETE CASCADE,
  counselor_id UUID REFERENCES public.counselors(id) ON DELETE CASCADE,
  match_confidence_score DECIMAL(3,2), -- 0.00 to 1.00
  match_reasoning TEXT, -- AI explanation
  status TEXT DEFAULT 'recommended', -- recommended, booked, declined
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.counselors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.intake_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.counselor_matches ENABLE ROW LEVEL SECURITY;

-- RLS Policies for counselors (public read)
CREATE POLICY "Counselors are viewable by everyone" 
ON public.counselors 
FOR SELECT 
USING (true);

-- RLS Policies for intake submissions (user-owned)
CREATE POLICY "Users can view their own intake submissions" 
ON public.intake_submissions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own intake submissions" 
ON public.intake_submissions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for counselor matches (user-owned via intake)
CREATE POLICY "Users can view their own matches" 
ON public.counselor_matches 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.intake_submissions 
    WHERE id = intake_submission_id AND user_id = auth.uid()
  )
);

CREATE POLICY "System can create matches" 
ON public.counselor_matches 
FOR INSERT 
WITH CHECK (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for counselors
CREATE TRIGGER update_counselors_updated_at
  BEFORE UPDATE ON public.counselors
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample counselors with varied therapeutic styles
INSERT INTO public.counselors (name, bio, specializations, languages, gender, years_experience, hourly_rate, therapeutic_styles, persona_scores) VALUES
('Dr. Sarah Chen', 'Compassionate therapist specializing in anxiety and depression with a warm, empathetic approach.', 
 ARRAY['anxiety', 'depression', 'trauma'], ARRAY['English', 'Mandarin'], 'Female', 8, 120.00,
 '{"CBT": 0.3, "humanistic": 0.8, "psychodynamic": 0.4}',
 '{"empathy": 0.9, "directness": 0.3, "structure": 0.5}'),

('Dr. Marcus Thompson', 'Direct, solution-focused therapist who uses CBT and practical strategies for rapid results.',
 ARRAY['CBT', 'workplace_stress', 'goal_setting'], ARRAY['English'], 'Male', 12, 150.00,
 '{"CBT": 0.9, "solution_focused": 0.8, "behavioral": 0.7}',
 '{"empathy": 0.5, "directness": 0.9, "structure": 0.8}'),

('Dr. Elena Rodriguez', 'Bilingual therapist with expertise in family dynamics and cultural sensitivity.',
 ARRAY['family_therapy', 'cultural_issues', 'relationships'], ARRAY['English', 'Spanish'], 'Female', 10, 130.00,
 '{"family_systems": 0.8, "multicultural": 0.9, "humanistic": 0.7}',
 '{"empathy": 0.8, "directness": 0.4, "cultural_sensitivity": 0.9}'),

('Dr. James Wilson', 'Psychodynamic therapist focused on deep exploration and long-term personal growth.',
 ARRAY['psychodynamic', 'personality_disorders', 'self_discovery'], ARRAY['English'], 'Male', 15, 180.00,
 '{"psychodynamic": 0.9, "insight_oriented": 0.8, "exploratory": 0.7}',
 '{"empathy": 0.7, "directness": 0.2, "depth": 0.9}');