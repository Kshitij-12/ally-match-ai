import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { freeTextInput, structuredData, userId } = await req.json();
    
    if (!freeTextInput || !userId) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // 1. Analyze user's free text input with AI to derive persona scores
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an expert therapeutic matching AI. Analyze the user's free-text input about their mental health concerns and derive persona scores that indicate their preferences for therapeutic style.

Return ONLY a JSON object with scores from 0.0 to 1.0 for:
- empathy_preference: How much they need emotional warmth vs clinical approach
- directness_preference: How much they prefer direct advice vs exploratory discussion  
- structure_preference: How much they want structured sessions vs open-ended
- depth_preference: How much they want deep exploration vs surface-level coping
- cbt_preference: How much they prefer cognitive behavioral approaches vs other styles

Example response: {"empathy_preference": 0.8, "directness_preference": 0.3, "structure_preference": 0.6, "depth_preference": 0.4, "cbt_preference": 0.7}`
          },
          {
            role: 'user',
            content: freeTextInput
          }
        ],
      }),
    });

    if (!aiResponse.ok) {
      console.error('AI API error:', aiResponse.status, await aiResponse.text());
      throw new Error('Failed to analyze user preferences with AI');
    }

    const aiData = await aiResponse.json();
    const aiPersonaScore = JSON.parse(aiData.choices[0].message.content);

    // 2. Store intake submission
    const { data: intakeData, error: intakeError } = await supabase
      .from('intake_submissions')
      .insert({
        user_id: userId,
        free_text_input: freeTextInput,
        structured_data: structuredData,
        ai_persona_score: aiPersonaScore
      })
      .select()
      .single();

    if (intakeError) {
      console.error('Intake insertion error:', intakeError);
      throw new Error('Failed to save intake submission');
    }

    // 3. Get all counselors
    const { data: counselors, error: counselorsError } = await supabase
      .from('counselors')
      .select('*');

    if (counselorsError) {
      console.error('Counselors fetch error:', counselorsError);
      throw new Error('Failed to fetch counselors');
    }

    // 4. Calculate match scores for each counselor
    const matches = counselors.map(counselor => {
      const counselorPersona = counselor.persona_scores || {};
      
      // Calculate compatibility score based on persona alignment
      let totalScore = 0;
      let weightSum = 0;
      
      // Empathy matching
      const empathyDiff = Math.abs((aiPersonaScore.empathy_preference || 0.5) - (counselorPersona.empathy || 0.5));
      const empathyScore = 1 - empathyDiff;
      totalScore += empathyScore * 0.3; // 30% weight
      weightSum += 0.3;
      
      // Directness matching  
      const directnessDiff = Math.abs((aiPersonaScore.directness_preference || 0.5) - (counselorPersona.directness || 0.5));
      const directnessScore = 1 - directnessDiff;
      totalScore += directnessScore * 0.25; // 25% weight
      weightSum += 0.25;
      
      // Structure matching
      const structureDiff = Math.abs((aiPersonaScore.structure_preference || 0.5) - (counselorPersona.structure || 0.5));
      const structureScore = 1 - structureDiff;
      totalScore += structureScore * 0.2; // 20% weight
      weightSum += 0.2;
      
      // CBT preference matching
      const cbtScore = aiPersonaScore.cbt_preference || 0.5;
      const counselorCbt = counselor.therapeutic_styles?.CBT || 0.3;
      const cbtMatch = 1 - Math.abs(cbtScore - counselorCbt);
      totalScore += cbtMatch * 0.25; // 25% weight
      weightSum += 0.25;
      
      const finalScore = totalScore / weightSum;
      
      // Generate reasoning
      const reasoning = `Match based on: Empathy alignment (${(empathyScore * 100).toFixed(0)}%), Direct communication style (${(directnessScore * 100).toFixed(0)}%), Session structure preference (${(structureScore * 100).toFixed(0)}%), CBT approach compatibility (${(cbtMatch * 100).toFixed(0)}%)`;
      
      return {
        counselor,
        score: Math.round(finalScore * 100) / 100, // Round to 2 decimals
        reasoning
      };
    });

    // 5. Sort by score and take top 3
    const topMatches = matches
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    // 6. Store match results
    const matchInserts = topMatches.map(match => ({
      intake_submission_id: intakeData.id,
      counselor_id: match.counselor.id,
      match_confidence_score: match.score,
      match_reasoning: match.reasoning
    }));

    const { error: matchError } = await supabase
      .from('counselor_matches')
      .insert(matchInserts);

    if (matchError) {
      console.error('Match insertion error:', matchError);
      throw new Error('Failed to save match results');
    }

    // 7. Return the top matches with counselor details
    const response = {
      intake_submission_id: intakeData.id,
      ai_persona_score: aiPersonaScore,
      matches: topMatches.map(match => ({
        counselor: match.counselor,
        match_confidence_score: match.score,
        match_reasoning: match.reasoning
      }))
    };

    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('AI counselor match error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});