import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Star, Clock, DollarSign, Languages, Award, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MatchResultsProps {
  matchData: {
    intake_submission_id: string;
    ai_persona_score: any;
    matches: Array<{
      counselor: any;
      match_confidence_score: number;
      match_reasoning: string;
    }>;
  };
  onBookSession?: (counselorId: string) => void;
}

export function MatchResults({ matchData, onBookSession }: MatchResultsProps) {
  const { toast } = useToast();

  const handleBookSession = (counselorId: string, counselorName: string) => {
    if (onBookSession) {
      onBookSession(counselorId);
    } else {
      toast({
        title: "Booking Session",
        description: `Booking session with ${counselorName}. This feature will be implemented soon!`,
      });
    }
  };

  const getMatchColor = (score: number) => {
    if (score >= 0.8) return "text-green-600";
    if (score >= 0.6) return "text-yellow-600";
    return "text-red-600";
  };

  const getMatchLabel = (score: number) => {
    if (score >= 0.85) return "Excellent Match";
    if (score >= 0.7) return "Very Good Match";
    if (score >= 0.6) return "Good Match";
    return "Potential Match";
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* AI Analysis Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-primary" />
            Your Therapeutic Style Profile
          </CardTitle>
          <CardDescription>
            Based on your responses, our AI identified these preferences:
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Object.entries(matchData.ai_persona_score || {}).map(([key, value]) => (
              <div key={key} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="capitalize">{key.replace('_preference', '').replace('_', ' ')}</span>
                  <span className="font-medium">{Math.round((value as number) * 100)}%</span>
                </div>
                <Progress value={(value as number) * 100} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Match Results */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Your Top Counselor Matches</h2>
        {matchData.matches.map((match, index) => {
          const { counselor, match_confidence_score, match_reasoning } = match;
          const matchPercentage = Math.round(match_confidence_score * 100);
          
          return (
            <Card key={counselor.id} className="border-l-4 border-l-primary">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      #{index + 1} {counselor.name}
                      {counselor.verified && (
                        <Award className="h-4 w-4 text-green-500" />
                      )}
                    </CardTitle>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {counselor.years_experience} years
                      </span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        ${counselor.hourly_rate}/session
                      </span>
                      {counselor.languages && (
                        <span className="flex items-center gap-1">
                          <Languages className="h-3 w-3" />
                          {counselor.languages.join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${getMatchColor(match_confidence_score)}`}>
                      {matchPercentage}%
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {getMatchLabel(match_confidence_score)}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{counselor.bio}</p>
                
                {/* Specializations */}
                {counselor.specializations && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium">Specializations:</span>
                    <div className="flex flex-wrap gap-1">
                      {counselor.specializations.map((spec: string) => (
                        <Badge key={spec} variant="secondary" className="text-xs">
                          {spec.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Match Reasoning */}
                <div className="bg-muted/50 p-3 rounded-lg">
                  <p className="text-sm">
                    <span className="font-medium">Why this match: </span>
                    {match_reasoning}
                  </p>
                </div>

                {/* Therapeutic Styles */}
                {counselor.therapeutic_styles && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium">Therapeutic Approaches:</span>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {Object.entries(counselor.therapeutic_styles).map(([style, score]) => (
                        <div key={style} className="flex justify-between text-xs">
                          <span className="capitalize">{style.replace('_', ' ')}</span>
                          <span className="font-medium">{Math.round((score as number) * 100)}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button 
                    onClick={() => handleBookSession(counselor.id, counselor.name)}
                    className="flex-1"
                  >
                    Book Session
                  </Button>
                  <Button variant="outline" className="flex-1">
                    View Profile
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}