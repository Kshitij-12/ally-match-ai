import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Heart, Brain, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface IntakeFormProps {
  onMatchesFound: (matches: any) => void;
  userId?: string;
}

export function IntakeForm({ onMatchesFound, userId }: IntakeFormProps) {
  const [freeTextInput, setFreeTextInput] = useState("");
  const [selectedSpecializations, setSelectedSpecializations] = useState<string[]>([]);
  const [preferredLanguage, setPreferredLanguage] = useState("");
  const [preferredGender, setPreferredGender] = useState("");
  const [budgetRange, setBudgetRange] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const specializations = [
    "anxiety", "depression", "trauma", "relationships", "family_therapy",
    "CBT", "workplace_stress", "cultural_issues", "personality_disorders",
    "self_discovery", "goal_setting"
  ];

  const handleSpecializationToggle = (specialization: string) => {
    setSelectedSpecializations(prev => 
      prev.includes(specialization)
        ? prev.filter(s => s !== specialization)
        : [...prev, specialization]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!freeTextInput.trim()) {
      toast({
        title: "Required Field",
        description: "Please tell us what brings you here today.",
        variant: "destructive",
      });
      return;
    }

    if (!userId) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to find counselor matches.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const structuredData = {
        specializations: selectedSpecializations,
        preferred_language: preferredLanguage,
        preferred_gender: preferredGender,
        budget_range: budgetRange
      };

      const { data, error } = await supabase.functions.invoke('ai-counselor-match', {
        body: {
          freeTextInput,
          structuredData,
          userId
        }
      });

      if (error) {
        console.error('Matching error:', error);
        throw new Error(error.message);
      }

      if (data.matches && data.matches.length > 0) {
        onMatchesFound(data);
        toast({
          title: "Matches Found!",
          description: `We found ${data.matches.length} highly compatible counselors for you.`,
        });
      } else {
        toast({
          title: "No Matches",
          description: "We couldn't find suitable matches. Please try adjusting your preferences.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error finding matches:', error);
      toast({
        title: "Error",
        description: "Failed to find counselor matches. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Brain className="h-6 w-6 text-primary" />
          Smart Counselor Matching
        </CardTitle>
        <CardDescription>
          Tell us about yourself and we'll use AI to find counselors that match your therapeutic style preferences
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Free Text Input - Most Important */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Heart className="h-4 w-4 text-red-500" />
              What brings you here today? *
            </label>
            <Textarea
              placeholder="Share what's on your mind, how you're feeling, or what you'd like to work on. The more you share, the better we can match you with the right counselor..."
              value={freeTextInput}
              onChange={(e) => setFreeTextInput(e.target.value)}
              className="min-h-[120px]"
              required
            />
            <p className="text-xs text-muted-foreground">
              This helps our AI understand your therapeutic style preferences
            </p>
          </div>

          {/* Specializations */}
          <div className="space-y-3">
            <label className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4 text-blue-500" />
              Areas of Focus (optional)
            </label>
            <div className="flex flex-wrap gap-2">
              {specializations.map((spec) => (
                <Badge
                  key={spec}
                  variant={selectedSpecializations.includes(spec) ? "default" : "outline"}
                  className="cursor-pointer transition-colors hover:bg-primary/80"
                  onClick={() => handleSpecializationToggle(spec)}
                >
                  {spec.replace('_', ' ')}
                </Badge>
              ))}
            </div>
          </div>

          {/* Additional Preferences */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Preferred Language</label>
              <Select value={preferredLanguage} onValueChange={setPreferredLanguage}>
                <SelectTrigger>
                  <SelectValue placeholder="Any language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Spanish">Spanish</SelectItem>
                  <SelectItem value="Mandarin">Mandarin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Preferred Gender</label>
              <Select value={preferredGender} onValueChange={setPreferredGender}>
                <SelectTrigger>
                  <SelectValue placeholder="No preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Non-binary">Non-binary</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Budget Range (per session)</label>
            <Select value={budgetRange} onValueChange={setBudgetRange}>
              <SelectTrigger>
                <SelectValue placeholder="Select budget range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="under-100">Under $100</SelectItem>
                <SelectItem value="100-150">$100 - $150</SelectItem>
                <SelectItem value="150-200">$150 - $200</SelectItem>
                <SelectItem value="over-200">Over $200</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Finding Your Perfect Matches...
              </>
            ) : (
              'Find My Counselor Matches'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}