import { useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { AuthForm } from "@/components/AuthForm";
import { IntakeForm } from "@/components/IntakeForm";
import { MatchResults } from "@/components/MatchResults";
import { Button } from "@/components/ui/button";
import { LogOut, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [matchData, setMatchData] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setMatchData(null);
    toast({
      title: "Signed Out",
      description: "You've been signed out successfully.",
    });
  };

  const handleMatchesFound = (matches: any) => {
    setMatchData(matches);
  };

  const resetMatches = () => {
    setMatchData(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        {user && (
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Smart Counselor Matching</h1>
              <p className="text-gray-600">Find the perfect therapeutic match with AI</p>
            </div>
            <div className="flex gap-2">
              {matchData && (
                <Button onClick={resetMatches} variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  New Search
                </Button>
              )}
              <Button onClick={handleSignOut} variant="outline" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="flex justify-center">
          {!user ? (
            <AuthForm onAuthSuccess={setUser} />
          ) : matchData ? (
            <MatchResults matchData={matchData} />
          ) : (
            <IntakeForm onMatchesFound={handleMatchesFound} userId={user.id} />
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
